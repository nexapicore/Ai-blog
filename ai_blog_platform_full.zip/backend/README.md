# AI Blog Platform - Backend

This is the Express/MongoDB backend.