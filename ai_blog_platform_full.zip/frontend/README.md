# AI Blog Platform - Frontend

This is the React frontend.